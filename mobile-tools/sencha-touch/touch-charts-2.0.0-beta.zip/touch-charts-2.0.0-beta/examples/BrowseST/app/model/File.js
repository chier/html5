Ext.define('File', {
    extend: 'Ext.data.Model',
    config: {
        fields: ['children', 'leaf', 'data', 'id', 'name']
    }
});
