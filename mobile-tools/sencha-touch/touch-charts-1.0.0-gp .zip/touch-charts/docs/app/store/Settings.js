/**
 * Store for keeping Docs app settings
 */
Ext.define('Docs.store.Settings', {
    extend: 'Ext.data.Store',
    model: 'Docs.model.Setting'
});
