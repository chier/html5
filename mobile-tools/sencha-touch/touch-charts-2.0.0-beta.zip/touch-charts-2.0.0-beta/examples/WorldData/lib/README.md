Installing Sencha Touch
-----------------------

Download the Sencha Touch v1.1 SDK from [here](http://www.sencha.com/products/touch/download/) and place (or symlink) the unzipped directory, renamed to <code>touch</code>, into this <code>lib</code> folder.

Also place (or symlink) the Touch Charts SDK, renamed to <code>charts</code>.