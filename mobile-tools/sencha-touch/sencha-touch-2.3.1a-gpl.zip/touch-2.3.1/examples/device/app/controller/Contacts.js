Ext.define('Device.controller.Contacts', {
    extend: 'Ext.app.Controller'
});
